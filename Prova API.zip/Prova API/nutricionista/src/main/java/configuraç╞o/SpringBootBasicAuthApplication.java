package br.senac.pr.exemplospringbootbasicauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootBasicAuthApplication {

    public static void main(String[] args) {
        SpringApplication.run(br.senac.pr.exemplospringbootbasicauth.SpringBootBasicAuthApplication.class, args);
    }

}
