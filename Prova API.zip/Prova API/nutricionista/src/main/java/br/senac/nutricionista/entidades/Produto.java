package br.senac.nutricionista.entidades;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
public class Produto {
    @Id
    @GeneratedValue
    private long id;
    @Column(nullable = false, unique = true)

    @NotBlank(message = "O nome não pode estar em branco")
    @Size(min = 3, message = "O nome deve ter pelo menos 3 caracteres")
    private String nome;


    @NotBlank(message = "O preco não pode estar em branco")
    @Size(min = 3, message = "O preco deve ter pelo menos 3 numeros")
    private double preco;

    @NotBlank(message = "A descricao não pode estar em branco")
    @Size(min = 3, message = "A descricao deve ter pelo menos 3 caracteres")
    private String descricao;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}
