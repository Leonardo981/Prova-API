package br.senac.nutricionista.controladores;

import br.senac.nutricionista.entidades.Estagiario;
import br.senac.nutricionista.repositorios.EstagiarioRepositorio;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;


@RestController
@RequestMapping("/estagiarios")
public class EstagiariosControlador {


    private EstagiarioRepositorio estagiarioRepositorio;

    public EstagiariosControlador(EstagiarioRepositorio estagiariosRepositorio) {
        this.estagiarioRepositorio = estagiariosRepositorio;
    }


    // GET: Obter todos os estagiarios com paginação
    @GetMapping
    public ResponseEntity<Page<Estagiario>> listarEstagiario(
            @RequestParam(defaultValue = "0") int pagina,
            @RequestParam(defaultValue = "10") int tamanhoPagina) {

        Pageable pageable = PageRequest.of(pagina, tamanhoPagina);
        Page<Estagiario> estagiarios = estagiarioRepositorio.findAll(pageable);

        return ResponseEntity.ok(estagiarios);
    }

    // GET: Obter um único estagiario por ID
    @GetMapping("/{id}")
    public ResponseEntity<Estagiario> obterEstagiarioPorId(@PathVariable Long id) {
        Optional<Estagiario> estagiario = estagiarioRepositorio.findById(id);
        return estagiario.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    // POST: Criar um novo estagiario
    @PostMapping
    public ResponseEntity<Estagiario> criarEstagiario(@RequestBody @Valid Estagiario estagiario) {
        Estagiario estagiarioCriado = estagiarioRepositorio.save(estagiario);
        return ResponseEntity.status(HttpStatus.CREATED).body(estagiarioCriado);
    }

    // PUT: Atualizar um estagiario existente por ID
    @PutMapping("/{id}")
    public ResponseEntity<Estagiario> atualizarEstagiario(@PathVariable Long id, @RequestBody Estagiario estagiarioAtualizado) {
        if (!estagiarioRepositorio.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        estagiarioAtualizado.setId(id);
        Estagiario estagiarioAtualizadoSalvo = estagiarioRepositorio.save(estagiarioAtualizado);
        return ResponseEntity.ok(estagiarioAtualizadoSalvo);
    }

    // DELETE: Excluir um estagiario por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluirEstagiario(@PathVariable Long id) {
        if (!estagiarioRepositorio.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        estagiarioRepositorio.deleteById(id);
        return ResponseEntity.noContent().build();
    }

}
