package br.senac.nutricionista.controladores;


import br.senac.nutricionista.entidades.Pacientes;
import br.senac.nutricionista.repositorios.EstagiarioRepositorio;
import br.senac.nutricionista.repositorios.PacientesRepositorio;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/pacientes")
public class PacientesControlador {

    private PacientesRepositorio pacientesRepositorio;

    public PacientesControlador(PacientesRepositorio pacientesRepositorio) {
        this.pacientesRepositorio = pacientesRepositorio;
    }


    // GET: Obter todos os pacientes com paginação
    @GetMapping
    public ResponseEntity<Page<Pacientes>> listarPacientes(
            @RequestParam(defaultValue = "0") int pagina,
            @RequestParam(defaultValue = "10") int tamanhoPagina) {

        Pageable pageable = PageRequest.of(pagina, tamanhoPagina);
        Page<Pacientes> pacientes = pacientesRepositorio.findAll(pageable);

        return ResponseEntity.ok(pacientes);
    }

    // GET: Obter um único paciente por ID
    @GetMapping("/{id}")
    public ResponseEntity<Pacientes> obterPacientesPorId(@PathVariable Long id) {
        Optional<Pacientes> pacientes = pacientesRepositorio.findById(id);
        return pacientes.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    // POST: Criar um novo paciente
    @PostMapping
    public ResponseEntity<Pacientes> criarPacientes(@RequestBody @Valid Pacientes pacientes) {
        Pacientes pacienteCriado = pacientesRepositorio.save(pacientes);
        return ResponseEntity.status(HttpStatus.CREATED).body(pacienteCriado);
    }

    // PUT: Atualizar um paciente existente por ID
    @PutMapping("/{id}")
    public ResponseEntity<Pacientes> atualizarPaciente(@PathVariable Long id, @RequestBody Pacientes pacientesAtualizado) {
        if (!pacientesRepositorio.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        pacientesAtualizado.setId(id);
        Pacientes pacientesAtualizadoSalvo = pacientesRepositorio.save(pacientesAtualizado);
        return ResponseEntity.ok(pacientesAtualizadoSalvo);
    }

    // DELETE: Excluir um paciente por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluirPaciente(@PathVariable Long id) {
        if (!pacientesRepositorio.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        pacientesRepositorio.deleteById(id);
        return ResponseEntity.noContent().build();
    }


}
