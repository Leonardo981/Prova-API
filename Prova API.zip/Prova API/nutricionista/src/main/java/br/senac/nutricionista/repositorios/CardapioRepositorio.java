package br.senac.nutricionista.repositorios;

import br.senac.nutricionista.entidades.Cardapio;
import br.senac.nutricionista.entidades.Nutricionista;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CardapioRepositorio extends JpaRepository<Cardapio, Long> {


    List<Cardapio> searchByNome(String nomeRefeicao);

    Cardapio findByNomeRefeicao(String nomeRefeicao);

    Cardapio findByCalorias(double calorias);

    @Query("select c from Cardapio c where lower(c.nomeRefeicao) like lower(concat(:termo, '%')) or lower(c.calorias) like lower(concat(:termo, '%'))")
    List<Cardapio> searchByNomeRefeicaoECalorias(@Param("termo") String termoBusca);


}
