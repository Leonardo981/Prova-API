package br.senac.nutricionista.repositorios;


import br.senac.nutricionista.entidades.Pacientes;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PacientesRepositorio extends JpaRepository<Pacientes, Long>{

    List<Pacientes> searchByNome(String nome);

    Pacientes findByNome(String nome);

    Pacientes findByIdade(double idade);

    Pacientes findByCidade(String cidade);

    Pacientes findByTelefone(double telefone);

    @Query("select c from Pacientes c where lower(c.nome) like lower(concat(:termo, '%')) or lower(c.idade) like lower(concat(:termo, '%')) or " +
            "lower(c.cidade) like lower(concat(:termo, '%')) or lower(c.telefone) like lower(concat(:termo, '%'))")
    List<Pacientes> searchByNomeEEmailEIdadeECidadeETelefone(@Param("termo") String termoBusca);

}
