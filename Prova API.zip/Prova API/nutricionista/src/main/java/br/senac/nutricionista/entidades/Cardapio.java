package br.senac.nutricionista.entidades;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;


@Entity
public class Cardapio {
    @Id
    @GeneratedValue
    private long id;
    @Column(nullable = false, unique = true)

    @NotBlank(message = "O nomeRefeicao não pode estar em branco")
    @Size(min = 3, message = "O nomeRefeicao deve ter pelo menos 3 caracteres")
    private String nomeRefeicao;

    @NotBlank(message = "O calorias não pode estar em branco")
    @Size(min = 3, message = "O calorias deve ter pelo menos 3 caracteres")
    private double calorias;


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNomeRefeicao() {
        return nomeRefeicao;
    }

    public void setNomeRefeicao(String nomeRefeicao) {
        this.nomeRefeicao = nomeRefeicao;
    }

    public double getCalorias() {
        return calorias;
    }

    public void setCalorias(double calorias) {
        this.calorias = calorias;
    }
}

