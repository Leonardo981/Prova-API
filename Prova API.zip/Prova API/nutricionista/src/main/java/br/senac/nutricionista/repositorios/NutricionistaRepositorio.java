package br.senac.nutricionista.repositorios;

import br.senac.nutricionista.entidades.Nutricionista;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NutricionistaRepositorio extends JpaRepository<Nutricionista, Long> {

        List<Nutricionista> searchByNome(String nome);

        Nutricionista findByNome(String nome);

        Nutricionista findByEmail(String email);

        @Query("select c from Nutricionista c where lower(c.nome) like lower(concat(:termo, '%')) or lower(c.email) like lower(concat(:termo, '%'))")
        List<Nutricionista> searchByNomeEEmail(@Param("termo") String termoBusca);
}

