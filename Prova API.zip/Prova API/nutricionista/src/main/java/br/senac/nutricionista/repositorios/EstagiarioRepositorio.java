package br.senac.nutricionista.repositorios;

import br.senac.nutricionista.entidades.Estagiario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EstagiarioRepositorio extends JpaRepository<Estagiario, Long>  {

    List<Estagiario> searchByNome(String nome);

    Estagiario findByNome(String nome);

    Estagiario findByEmail(String email);

    @Query("select c from Estagiario c where lower(c.nome) like lower(concat(:termo, '%')) or lower(c.email) like lower(concat(:termo, '%'))")
    List<Estagiario> searchByNomeEEmail(@Param("termo") String termoBusca);
}

