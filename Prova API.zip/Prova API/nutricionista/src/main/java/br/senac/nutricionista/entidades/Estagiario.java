package br.senac.nutricionista.entidades;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;


@Entity
public class Estagiario {
    @Id
    @GeneratedValue
    private long id;
    @Column(nullable = false, unique = true)

    @NotBlank(message = "O nome não pode estar em branco")
    @Size(min = 3, message = "O nome deve ter pelo menos 3 caracteres")
    private String nome;


    @NotBlank(message = "O email não pode estar em branco")
    @Size(min = 3, message = "O email deve ter pelo menos 3 caracteres")
    private String email;


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email){this.email = email;}
    }
