package br.senac.nutricionista.controladores;

import br.senac.nutricionista.entidades.Cardapio;
import br.senac.nutricionista.entidades.Nutricionista;
import br.senac.nutricionista.repositorios.CardapioRepositorio;
import br.senac.nutricionista.repositorios.NutricionistaRepositorio;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;


@RestController
@RequestMapping("/cardapio")
public class CardapioControlador {

    private CardapioRepositorio cardapioRepositorio;

    public CardapioControlador(CardapioRepositorio cardapioRepositorio) {
        this.cardapioRepositorio = cardapioRepositorio;
    }


    // GET: Obter todos os cardapios com paginação
    @GetMapping
    public ResponseEntity<Page<Cardapio>> listarCardapio(
            @RequestParam(defaultValue = "0") int pagina,
            @RequestParam(defaultValue = "10") int tamanhoPagina) {

        Pageable pageable = PageRequest.of(pagina, tamanhoPagina);
        Page<Cardapio> cardapio = cardapioRepositorio.findAll(pageable);

        return ResponseEntity.ok(cardapio);
    }

    // GET: Obter um único cardapio por ID
    @GetMapping("/{id}")
    public ResponseEntity<Cardapio> obterCardapioPorId(@PathVariable Long id) {
        Optional<Cardapio> cardapio = cardapioRepositorio.findById(id);
        return cardapio.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    // POST: Criar um novo cardapio
    @PostMapping
    public ResponseEntity<Cardapio> criarCardapio(@RequestBody  @Valid Cardapio cardapio) {
        Cardapio cardapioCriado = cardapioRepositorio.save(cardapio);
        return ResponseEntity.status(HttpStatus.CREATED).body(cardapioCriado);
    }

    // PUT: Atualizar um cardapio existente por ID
    @PutMapping("/{id}")
    public ResponseEntity<Cardapio> atualizarCardapio(@PathVariable Long id, @RequestBody Cardapio cardapioAtualizado) {
        if (!cardapioRepositorio.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        cardapioAtualizado.setId(id);
        Cardapio cardapioAtualizadoSalvo = cardapioRepositorio.save(cardapioAtualizado);
        return ResponseEntity.ok(cardapioAtualizadoSalvo);
    }

    // DELETE: Excluir um cardapio por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluirCardapio(@PathVariable Long id) {
        if (!cardapioRepositorio.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        cardapioRepositorio.deleteById(id);
        return ResponseEntity.noContent().build();
    }


}
