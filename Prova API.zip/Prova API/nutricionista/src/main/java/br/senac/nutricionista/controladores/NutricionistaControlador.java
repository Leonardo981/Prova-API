package br.senac.nutricionista.controladores;



import br.senac.nutricionista.entidades.Nutricionista;
import br.senac.nutricionista.repositorios.NutricionistaRepositorio;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;


@RestController
@RequestMapping("/nutricionista")
public class NutricionistaControlador {

    private NutricionistaRepositorio nutricionistaRepositorio;

    public NutricionistaControlador(NutricionistaRepositorio nutricionistaRepositorio) {
        this.nutricionistaRepositorio = nutricionistaRepositorio;
    }


    // GET: Obter todos nutricionista com paginação
    @GetMapping
    public ResponseEntity<Page<Nutricionista>> listarNutricionistas(
            @RequestParam(defaultValue = "0") int pagina,
            @RequestParam(defaultValue = "10") int tamanhoPagina) {

        Pageable pageable = PageRequest.of(pagina, tamanhoPagina);
        Page<Nutricionista> nutricionistas = nutricionistaRepositorio.findAll(pageable);

        return ResponseEntity.ok(nutricionistas);
    }

    // GET: Obter um único nutricionista por ID
    @GetMapping("/{id}")
    public ResponseEntity<Nutricionista> obterNutricionistaPorId(@PathVariable Long id) {
        Optional<Nutricionista> nutricionista = nutricionistaRepositorio.findById(id);
        return nutricionista.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    // POST: Criar um novo nutricionista
    @PostMapping
    public ResponseEntity<Nutricionista> criarNutricionista(@RequestBody @Valid Nutricionista nutricionista) {
        Nutricionista nutricionistaCriado = nutricionistaRepositorio.save(nutricionista);
        return ResponseEntity.status(HttpStatus.CREATED).body(nutricionistaCriado);
    }

    // PUT: Atualizar um nutricionista existente por ID
    @PutMapping("/{id}")
    public ResponseEntity<Nutricionista> atualizarNutricionista(@PathVariable Long id, @RequestBody Nutricionista nutricionistaAtualizado) {
        if (!nutricionistaRepositorio.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        nutricionistaAtualizado.setId(id);
        Nutricionista nutricionistaAtualizadoSalvo = nutricionistaRepositorio.save(nutricionistaAtualizado);
        return ResponseEntity.ok(nutricionistaAtualizadoSalvo);
    }

    // DELETE: Excluir um nutricionista por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluirNutricionista(@PathVariable Long id) {
        if (!nutricionistaRepositorio.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        nutricionistaRepositorio.deleteById(id);
        return ResponseEntity.noContent().build();
    }

}
