package br.senac.nutricionista;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NutricionistaApplicationTests {

	@Test
	void contextLoads() {
	}

}
